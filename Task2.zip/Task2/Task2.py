import cv2
import time
from deepface import DeepFace

cap = cv2.VideoCapture(0)

last_time = 0
DELAY = 1.5  # thoda fast

age_buffer = []
gender_buffer = []

def get_mode(lst):
    return max(set(lst), key=lst.count) if lst else "Unknown"

while True:

    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    current_time = time.time()

    text = "Detecting..."

    if current_time - last_time > DELAY:

        try:
            results = DeepFace.analyze(
                frame,
                actions=['age', 'gender'],
                enforce_detection=False,   # faster
                detector_backend='opencv'  # FAST FIX
            )

            if isinstance(results, list):
                results = results[0]

            age = int(results.get('age', 0))

            gender_data = results.get('gender', {})
            gender = max(gender_data, key=gender_data.get)

            age_buffer.append(age)
            gender_buffer.append(gender)

            if len(age_buffer) > 5:
                age_buffer.pop(0)
                gender_buffer.pop(0)

            avg_age = int(sum(age_buffer) / len(age_buffer))
            stable_gender = get_mode(gender_buffer)

            text = f"{stable_gender}, Age: {avg_age}"

            last_time = current_time

        except Exception as e:
            text = "Processing..."

    cv2.putText(frame, text, (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                1, (0, 255, 0), 2)

    cv2.imshow("Fast DeepFace", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()